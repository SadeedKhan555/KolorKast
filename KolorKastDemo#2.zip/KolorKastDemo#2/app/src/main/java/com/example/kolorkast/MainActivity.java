package com.example.kolorkast;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.graphics.Color;

import androidx.appcompat.app.AppCompatActivity;



public class MainActivity extends AppCompatActivity {
    ImageView imageView;
    ImageView background;
    ImageView menu;
    ImageButton cameraButton;
    TextView ColorValues;
    View ColorViews;
    Bitmap bitmap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Setup buttons, images, and text onto screen
        setContentView(R.layout.activity_main);
        cameraButton = findViewById(R.id.button);
        imageView = findViewById(R.id.imageView);
        background = findViewById(R.id.imageView2);
        menu = findViewById(R.id.imageView4);
        ColorValues = findViewById(R.id.displayValues);
        ColorViews = findViewById(R.id.displayColors);

//        //open camera instantly
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, 0);


        //restart app button to clear the image from layer from the previous picture
        cameraButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                finish();
                startActivity(getIntent());
            }
        });


//        cameraButton.setOnClickListener(v -> {
//            Intent intent2 = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//            startActivityForResult(intent2, 0);
//        });


    }


    //image sent from camera to application
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //image converted to bitmap to read the pixel values
        final Bitmap[] bitmap = {(Bitmap) data.getExtras().get("data")};

        for (int i = 0; i<bitmap.length; i++){
            imageView.setImageBitmap(bitmap[i]);
        }


        imageView = findViewById(R.id.imageView);
        ColorValues = findViewById(R.id.displayValues);

        imageView.setDrawingCacheEnabled(true);
        imageView.buildDrawingCache(true);

        //when screen is touched then Color values display along with the color at the bottom
        imageView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE) {
                    for (int i = 0; i<bitmap.length; i++){
                        bitmap[i] = imageView.getDrawingCache();
                    }




                    int pixels = bitmap[0].getPixel((int)event.getX(),(int)event.getY());


                    int r = Color.red(pixels);
                    int g = Color.green(pixels);
                    int b = Color.blue(pixels);

                    String hex = "#" + Integer.toHexString(pixels);
                    ColorViews.setBackgroundColor(Color.rgb(r,g,b));
                    ColorValues.setText("RGB "+r+", "+g+", "+b+" \nHex:" +hex);

//                    float[] hsv = new float[3];
//
//                    Color.RGBToHSV(r, g, b, hsv);
//
//                    float hue = hsv[0];
//                    float sat = hsv[1];
//                    float val = hsv[2];

                    double Hue = getHue(r,g,b);

                    System.out.println(Hue);

                }
                return true;
            }
        });
    }

    //Get hue function calculator
    public double getHue(int red, int green, int blue){

        double hue_y = 2*red-green-blue;
        double hue_x = Math.sqrt(3)*(green-blue);

        double hue_radian = Math.atan2(hue_y,hue_x);

        double hue_degrees = hue_radian*(180/Math.PI);

        double hue = hue_degrees%360;


        return (hue);
    }

}